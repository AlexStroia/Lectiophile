package com.example.xyzreader.model;

public class Book {

    private String id;
    private String title;
    private String author;
    private String body;
    private String thumb;
    private Double aspect_ratio;
    private String published_date;

    public Book(String id, String title, String author, String body, String thumb, Double aspect_ratio, String published_date) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.body = body;
        this.thumb = thumb;
        this.aspect_ratio = aspect_ratio;
        this.published_date = published_date;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id='" + id + '\'' +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", body='" + body + '\'' +
                ", thumb='" + thumb + '\'' +
                ", aspect_ratio=" + aspect_ratio +
                ", published_date='" + published_date + '\'' +
                '}';
    }
}
