package com.example.xyzreader.utils;

public class Constants {
    public static final int CIRCULAR_PROGRESS_TIME = 5000;
    public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.sss";
    public static final int DISTANCE_DECORATION = 24;
}
