# Lectiophile
